#include<iostream>
using namespace std;
class  Fruit
{
protected:
string color;
public:
Fruit (string c)
{ color=c;
}
virtual void Taste()=0;
virtual void EatingMethod()=0;
void showcolor()
{ cout <<"Color="<<color<<endl;}
};
class Apple: public Fruit 
{ public:
Apple (string c): Fruit (c)
{ color=c;}
void Taste() override 
{ cout <<"Taste=Sweet and Crunchy"<<endl;}
void EatingMethod() override 
{ cout <<"Eating Method=Eat slice "<<endl;}
};
class Banana: public Fruit 
{ public:
Banana (string c): Fruit (c)
{ color=c;}
void Taste() override
{
cout <<" Taste=Soft and Sweet"<<endl;}
void EatingMethod() override 
{ cout <<" Eating Method=Peel and eat"<<endl;}
};
int main ()
{
Apple myapple("Red");
Banana mybanana("Yellow");
myapple.Taste();
myapple.EatingMethod();
mybanana.Taste();
mybanana.EatingMethod();
}
