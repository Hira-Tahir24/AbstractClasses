#include<iostream>
using namespace std;

class Shape 
{
public:
 virtual void draw()=0;
 };
 class Circle: public Shape 
 {
 public:
 void draw() override 
 { cout <<"Circle is inherited"<<endl;
 }
 };
 class Rectangle: public Shape 
 { public:
 void draw() override 
 {
 cout <<"Rectangle is inherited"<<endl;
 }
 };

int main() {
    Shape* shape[2];
    shape[0] =  new Circle();
    shape[1] =  new Rectangle();

    for (int i = 0; i < 2; i++) {
         shape[i]->draw();
    }
for (int i=0;i<2;i++)
{
delete shape[i];
}

    return 0;
}
