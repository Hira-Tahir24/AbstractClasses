#include<iostream>
using namespace std;
class Employee 
{ public: 
virtual  void calculateSalary()=0;
};
class FullTimeEmployee : public Employee 
{ public:
void calculateSalary()
{ cout <<" Salary is Rs.55000"<<endl;
}
};
class PartTimeEmployee: public Employee 
{ public:
void calculateSalary()
{ cout <<"Salary is Rs.4000"<<endl;
}
};
int main ()
{ FullTimeEmployee obj1;
 PartTimeEmployee obj2;
obj1.calculateSalary();
obj2.calculateSalary();
} 