#include<iostream>
using namespace std;
class Shape 
{ public:
virtual void calculateArea()=0;
};
class Square: public Shape 
{
public:
void calculateArea () override 
{
int side_length=4;
int area;
area=side_length*side_length;
cout <<"Area of Square="<<area<<endl;
}
}; 
class Rectangle: public Shape 
{ public:
void calculateArea() override 
{
int base=5;
int height=6;
int area=(base*height)/2;
cout <<"Area of Rectangle="<<area<<endl;
}
};
int main ()
{
Square s;
Rectangle r;
s.calculateArea();
r.calculateArea();
}