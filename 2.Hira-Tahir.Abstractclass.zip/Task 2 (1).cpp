#include<iostream>
using namespace std;

class Vehicle 
{
public:
 virtual void getNumberOfWheels()=0;
 };
 class Car: public Vehicle 
 {
 public:
 void getNumberOfWheels() override 
 { cout <<"Car has 4 wheels"<<endl;
 }
 };
 class Bike: public Vehicle 
 { public:
 void getNumberOfWheels() override 
 {
 cout <<"Bike has 2 wheels"<<endl;
 }
 };


int main() {
    Vehicle* vehicles[2];
    vehicles[0] =  new Car();
    vehicles[1] =  new Bike();

    for (int i = 0; i < 2; i++) {
         vehicles[i]->getNumberOfWheels();
    }
for (int i=0;i<2;i++)
{
delete vehicles[i];
}

    return 0;
}
